package webd4201.ClossG;

import java.text.SimpleDateFormat;
import java.util.Vector;
import java.sql.*;

import java.util.Date;

/**
 * @author Grayson Closs
 *
 */

public class StudentDA {
	
	//static constants
	@SuppressWarnings("unused")
	private static final SimpleDateFormat SQL_DF = new SimpleDateFormat("yyyy-MM-dd");
	
	//static
	static Connection aConnection;
	static Statement aStatement;
	
	//static 
	static Vector<Student> Students = new Vector<Student>();
	static Student aStudent;
	
	//instance attributes
	static long id;
	static String password;
	static String stuPass;
	static String firstName;
	static String lastName; 
	static String emailAddress;
	static java.sql.Date lastAccess;
	static java.sql.Date enrolDate;
	static boolean enabled;
	static char type;
	static String programCode;
	static String programDescription;
	static int year;
	
	
	
	// establish the database connection
	/**
	 * 
	 * @param conn
	 */
	public static void initialize(Connection conn)
	{
            try {
                aConnection = conn;
                aStatement = aConnection.createStatement();
            }
            catch (SQLException e) { 
            	System.out.println(e);	
            }
	}
	/**
	 * 
	 */
	public static void terminate()
	{
            try{ 	// close the statement
                aStatement.close();
            }
            catch (SQLException e){
            	System.out.println(e);	
            }
	}
	
	/**
	 * 
	 * @param aStudent
	 * @return
	 * @throws DuplicateException
	 */
	public static boolean create(Student aStudent) throws DuplicateException
	{	
		boolean inserted = false; //insertion success flag
		// retrieve the customer attribute values
		id = aStudent.getId();
		password = aStudent.getPassword();
		firstName = aStudent.getFirstName();
		lastName = aStudent.getLastName();
		emailAddress = aStudent.getEmailAddress();
		lastAccess = new java.sql.Date (aStudent.getLastAccess().getTime());
		enrolDate = new java.sql.Date (aStudent.getEnrolDate().getTime());
		enabled = aStudent.isEnabled();
		type = aStudent.getType();
		programCode = aStudent.getProgramCode();
		programDescription = aStudent.getProgramDescription();
		year = aStudent.getYear();
		
	
		
		//insert string
		final String insertUser = "INSERT INTO users VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";//, id, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enabled, type);
		final String insertStudent = "INSERT INTO students (CollegeId, ProgramCode, ProgramDescription, CurrentYear) VALUES(?, ?, ?, ?)";//, CollegeId, programCode, programDescription, year);
		
		// see if this customer already exists in the database
		try {
			retrieve(id);
			throw (new DuplicateException("Problem with creating Student record, ID: " + id +" already exists in the system."));
		}
		// if NotFoundException, add customer to database
		catch(NotFoundException e)
		{
			try {  
				PreparedStatement stmtUser = aConnection.prepareStatement(insertUser);
				stmtUser.setLong(1, id);
				stmtUser.setString(2, password);
				stmtUser.setString(3, firstName);
				stmtUser.setString(4, lastName);
				stmtUser.setString(5, emailAddress);
				stmtUser.setDate(6, lastAccess);
				stmtUser.setDate(7, enrolDate);
				stmtUser.setBoolean(8, enabled);
				stmtUser.setString(9, String.valueOf(type));
				PreparedStatement stmtStudent = aConnection.prepareStatement(insertStudent);
				stmtStudent.setLong(1, id);
				stmtStudent.setString(2, programCode);
				stmtStudent.setString(3, programDescription);
				stmtStudent.setInt(4, year);
				// execute the SQL update statement
	    		stmtUser.execute();
	    		stmtStudent.execute();
	    		inserted = true;
	    			   		
			}
			catch (SQLException ee) { 
				System.out.println(ee);	
			}
		}
		return inserted;
	}
	/**
	 * 
	 * @param key
	 * @return
	 * @throws NotFoundException
	 */
	public static Student retrieve(long key) throws NotFoundException { // retrieve Customer and Boat data
		aStudent = null;
		
		final String selectStudent = "SELECT u.CollegeId, u.Password, u.FirstName, u.LastName, u.EmailAddress, u.LastAccess, u.EnrolDate, u.Enabled, u.Type, "
				+ "s.ProgramCode, s.ProgramDescription, s.CurrentYear "
				+ "From users u, students s "
				+ "WHERE u.CollegeId = s.CollegeId AND u.CollegeId = ?";
		
	 	// execute the SQL query statement
		try
 		{
			PreparedStatement stmtStudent = aConnection.prepareStatement(selectStudent);
			stmtStudent.setLong(1, key);
			
			ResultSet rs = stmtStudent.executeQuery();
            // next method sets cursor & returns true if there is data
            boolean gotIt = rs.next();
            if (gotIt) {	// extract the data
            	id = rs.getInt("CollegeId");
            	password = rs.getString("password");
            	firstName = rs.getString("FirstName");
            	lastName = rs.getString("LastName");
            	emailAddress = rs.getString("EmailAddress");
            	lastAccess = rs.getDate("LastAccess");
            	enrolDate = rs.getDate("EnrolDate");
            	enabled = rs.getBoolean("Enabled");
            	type = rs.getString("Type").charAt(0);
            	programCode = rs.getString("ProgramCode");
            	programDescription = rs.getString("ProgramDescription");
            	year = rs.getInt("CurrentYear");
			
                        try{
                            aStudent = new Student(id, password, firstName, lastName, emailAddress, lastAccess, enrolDate, enabled, type, programCode, programDescription, year);
                            
                        }catch (InvalidUserDataException e) { 
                        	System.out.println("Record for " + id + " contains an invalid Id. Student already exists.");
                        }
                    }else {
                    	throw (new NotFoundException("Problem retrieving Student record, Id number " + key + " does not exist in the system."));
                    }
                    rs.close();
	   	}catch (SQLException e) { 
	   		System.out.println(e);
	   	}
                
		return aStudent;
	}
	/**
	 * 
	 * @param aStudent
	 * @return
	 * @throws NotFoundException
	 */
	public static int update(Student aStudent) throws NotFoundException
	{	
		int records = 0;  //records updated in method
		
		// retrieve the customer argument attribute values
		id = aStudent.getId();
		password = aStudent.getPassword();
		firstName = aStudent.getFirstName();
		lastName = aStudent.getLastName();
		emailAddress = aStudent.getEmailAddress();
		lastAccess = new java.sql.Date (aStudent.getLastAccess().getTime());
		enrolDate = new java.sql.Date (aStudent.getEnrolDate().getTime());
		enabled = aStudent.isEnabled();
		type = aStudent.getType();
		programCode = aStudent.getProgramCode();
		programDescription = aStudent.getProgramDescription();
		year = aStudent.getYear();

		// define the SQL query statement using the phone number key
		final String updateUser = "UPDATE users SET Password   = ?, FirstName   = ?, LastName   = ?, EmailAddress   = ?, LastAccess   = ?, EnrolDate  = ?, Enabled   = ?, Type   = ? Where CollegeId   = ?";
		final String updateStudent = "UPDATE students SET ProgramCode   = ?, ProgramDescription   = ?, CurrentYear   = ? WHERE CollegeId   = ?";
				
		// see if this customer exists in the database
		// NotFoundException is thrown by find method
		try
		{
			PreparedStatement stmtUser = aConnection.prepareStatement(updateUser);
			stmtUser.setString(1, password);
			stmtUser.setString(2, firstName);
			stmtUser.setString(3, lastName);
			stmtUser.setString(4, emailAddress);
			stmtUser.setDate(5, lastAccess);
			stmtUser.setDate(6, enrolDate);
			stmtUser.setBoolean(7, enabled);
			stmtUser.setString(8, String.valueOf(type));
			stmtUser.setLong(9, id);
			PreparedStatement stmtStudent = aConnection.prepareStatement(updateStudent);
			stmtStudent.setString(1, programCode);
			stmtStudent.setString(2, programDescription);
			stmtStudent.setInt(3, year);
			stmtStudent.setLong(4, id);
            Student.retrieve(id);  //determine if there is a Customer recrod to be updated
                    // if found, execute the SQL update statement
                    records = stmtUser.executeUpdate();
                    records = stmtStudent.executeUpdate();
		}catch(NotFoundException e)
		{
			throw new NotFoundException("Student with ID " + id 
					+ " cannot be updated, does not exist in the system.");
		}catch (SQLException e) {
			System.out.println(e);
		}
		return records;
	}
	/**
	 * 
	 * @param aStudent
	 * @return
	 * @throws NotFoundException
	 */
	public static int delete(Student aStudent) throws NotFoundException
	{	
		int records = 0;
		// retrieve the phone no (key)
		id = aStudent.getId();
		// create the SQL delete statement
		String deleteStudent = "DELETE FROM students WHERE CollegeId = ?";
		String deleteUser = "DELETE FROM users WHERE CollegeId = ?";
		
		// see if this customer already exists in the database
		try {
			
			PreparedStatement stmtStudent = aConnection.prepareStatement(deleteStudent);
			stmtStudent.setLong(1, id);
			PreparedStatement stmtUser = aConnection.prepareStatement(deleteUser);
			stmtUser.setLong(1, id);
			Student.retrieve(id);  //used to determine if record exists for the passed Customer
    		// if found, execute the SQL update statement
    		records = stmtStudent.executeUpdate();
    		records = stmtUser.executeUpdate();
		}catch (NotFoundException e) {
			
			throw new NotFoundException("Student with ID " + id 
					+ " cannot be deleted, does not exist.");
			
		}catch (SQLException e) { 
			System.out.println(e);	
		}
		return records;
	}
	
	public static Student authenticate (long num, String pass) throws NotFoundException {
		
		Student stuAuth = null;
		String err = "";
		String authStudent = "select collegeid, password FROM users WHERE collegeid = ?";
		
		try {
			stuPass = Student.hashPassword(pass).toString();
			PreparedStatement stmtId = aConnection.prepareStatement(authStudent);
			stmtId.setLong(1, num);
			ResultSet rs = stmtId.executeQuery();
            // next method sets cursor & returns true if there is data
            if(rs.next()) {
            	id = rs.getInt("CollegeId");
            	password = rs.getString("password").toString();
            	if (num == id) {
    				if (stuPass.compareTo(password) == 0){
    					stuAuth = Student.retrieve(num);
    				}
    				else {
    					throw new SQLException("Pass no matchy");
    				}
    			}
    			else {
    				throw new SQLException();
    			}
            } else {
            	throw new SQLException();
            }

			
		} catch (SQLException e) {
			
			throw new NotFoundException("The user details provided do not exist in the database." + e.getMessage() + err);
		
		} catch (InvalidPasswordException p) {
			
			System.out.println(p);
			
		} catch (Exception e) {
			
			System.out.println(e.getMessage());
			
		}
		
		return stuAuth;
	}
	
}


