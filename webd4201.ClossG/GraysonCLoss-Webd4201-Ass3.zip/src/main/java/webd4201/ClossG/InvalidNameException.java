/**
 * 
 */
package webd4201.ClossG;
@SuppressWarnings(value = "serial")
/**
  * @author Grayson Closs
 * @version 1.0
 * @since 2023-01-20
 *
 */
public class InvalidNameException extends Exception{

	/**
	 * 
	 */
	public InvalidNameException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidNameException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
