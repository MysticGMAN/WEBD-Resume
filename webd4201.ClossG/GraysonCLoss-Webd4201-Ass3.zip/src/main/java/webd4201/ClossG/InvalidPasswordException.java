/**
 * 
 */
package webd4201.ClossG;
@SuppressWarnings(value = "serial")
/**
 * @author Grayson Closs
 * @version 1.0
 * @since 2023-01-20
 */
public class InvalidPasswordException extends Exception{

	public InvalidPasswordException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidPasswordException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
