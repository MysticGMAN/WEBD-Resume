package webd4201.ClossG;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HttpSession ses = null;   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		doPost(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("I am here in doPost.");
		ses = request.getSession(true);
		try {
			Long username = 100597686L;
			String password = "100597686";
			
			System.out.println("After the ses");
			Connection c = null;
			c = DatabaseConnect.initialize();
	        Student.initialize(c);
	        System.out.println("After the connection");
	        
	        username = Long.parseLong(request.getParameter("inputId").trim());
	        
	        System.out.println("After the connection pt 2");
//	        System.out.println("after the try block!");
//	        System.out.println(username.toString());
			password = request.getParameter("inputPassword").trim().toString();
//			System.out.println(password);
			System.out.println("After the get input values");
			// memorize the values in the session
			//System.out.println(username + password);
			//TODO do five more time so it can be displayed inside the register page
			
				
			Student stud = Student.authenticate(username, password);
			System.out.println("success validation");
			ses.setAttribute("firstname", stud.getFirstName());
			ses.setAttribute("id", stud.getId());
			response.sendRedirect("dashboard.jsp");
				
				
			} catch (Exception e) {
				System.out.println("fail validation" + e.getMessage());
				response.sendRedirect("register.jsp");
			}
		
		
		
		
	}

}
